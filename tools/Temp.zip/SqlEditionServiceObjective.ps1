[string]$webrootPath = $env:WEBROOT_PATH

[string]$webConfigFileName = Join-Path $webrootPath "web.config"

Write-Output "Configuration at '$webConfigFileName'"

[xml]$webConfigXml = Get-Content $webConfigFileName

[string]$connectionString = Select-Xml -Xml $webConfigXml -XPath "/configuration/appSettings/add[@key='setting.capita.agora.database.sql-connection-string']/@value"

$connectionStringBuilder = New-Object System.Data.SqlClient.SqlConnectionStringBuilder($connectionString)

[string]$server = $connectionStringBuilder.DataSource
[string]$database = $connectionStringBuilder.InitialCatalog

Write-Output "Server is '$server'"
Write-Output "Database is '$database'"

[string]$actualEdition = ""
[string]$actualServiceObjective = ""
[string]$expectedEdition = ""
[string]$expectedServiceObjective = ""

$connection = New-Object System.Data.SqlClient.SqlConnection($connectionString)
try
{
	$connection.Open()

	$getCommand = New-Object System.Data.SqlClient.SqlCommand("dbo.System_GetEditionServiceObjective", $connection)
	try
	{
		$getCommand.CommandType = [System.Data.CommandType]::StoredProcedure

		$dataReader = $getCommand.ExecuteReader()
		try
		{
			if (!$dataReader.Read())
			{
				throw "Expected data missing."
			}
			
			$actualEdition = $dataReader.GetString(0);
			$actualServiceObjective = $dataReader.GetString(1);
			$expectedEdition = $dataReader.GetString(2);
			$expectedServiceObjective = $dataReader.GetString(3);

			Write-Output "Actual Edition is '$actualEdition' and ServiceObjective is '$actualServiceObjective'"
			Write-Output "Expected Edition is '$expectedEdition' and ServiceObjective is '$expectedServiceObjective'"
		}
		finally
		{
			$dataReader.Dispose()
		}
	}
	finally
	{
		$getCommand.Dispose()
	}

	if ($actualEdition -eq "Unknown" -or $actualServiceObjective -eq "Unknown")
	{
		Write-Output "Unable to get actual Edition and ServiceObjective."
	}
	elseif ($actualEdition -eq $expectedEdition -and $actualServiceObjective -eq $expectedServiceObjective)
	{
		Write-Output "Database already is the expected Edition and ServiceObjective."
	}
	else
	{
		[string]$commandText = "alter database $database modify (edition = '$expectedEdition', service_objective = '$expectedServiceObjective')"

		$setCommand = New-Object System.Data.SqlClient.SqlCommand($commandText, $connection)
		try
		{
			$result = $setCommand.ExecuteNonQuery()
			
			Write-Output "Requested Edition to be '$expectedEdition' and ServiceObjective to be '$expectedServiceObjective'"
		}
		finally
		{
			$setCommand.Dispose()
		}
	}
}
finally
{
	$connection.Dispose()
}
