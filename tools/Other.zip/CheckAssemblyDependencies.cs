using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace CheckAssemblyDependencies
{
    internal static class Program
    {
        private static List<string> _wellKnownAssemblies;
        private static List<string> _missingAssemblies;

        private const string TOP_LEVEL = "<TopLevel>";
        
        public static void Main(string[] args)
        {
            if (!args.Any())
            {
                Console.WriteLine("There were no assemblies specified as arguments!");
            }
            else
            {
                _wellKnownAssemblies = new List<string> {
                    "mscorlib",
                    "System",
                    "System.ComponentModel.DataAnnotations",
                    "System.Configuration",
                    "System.Configuration.Install",
                    "System.Core",
                    "System.Data",
                    "System.Data.Entity.Design",
                    "System.Data.Entity",
                    "System.Data.OracleClient",
                    "System.Data.Services.Client",
                    "System.Design",
                    "System.Drawing",
                    "System.IdentityModel",
                    "System.Management",
                    "System.Runtime.Caching",
                    "System.Runtime.Serialization",
                    "System.ServiceModel",
                    "System.ServiceModel.Activation",
                    "System.ServiceModel.Web",
                    "System.ServiceProcess",
                    "System.Transactions",
                    "System.Web",
                    "System.Web.Extensions",
                    "System.Web.Services",
                    "System.Windows.Forms",
                    "System.Xml",
                    "System.Xml.Linq",
                    "Microsoft.CSharp",
                    "Microsoft.VisualC",
                };
                _missingAssemblies = new List<string>();
                
                Console.WriteLine("{0} assembly(ies) specified as arguments...", args.Length);
                Console.WriteLine();
                foreach (string arg in args)
                {
                    Console.WriteLine("Considering the assembly '{0}'...", arg);
                    _missingAssemblies.Clear();
                    CheckDependencies(arg, TOP_LEVEL, 0);
                    if (_missingAssemblies.Any())
                    {
                        _missingAssemblies.Sort();
                        Console.WriteLine("Missing the following {0} assembly(ies):", _missingAssemblies.Count);
                        foreach (string missingAssembly in _missingAssemblies)
                        {
                            Console.WriteLine(" * {0}", missingAssembly);
                        }
                    }
                    else
                    {
                        Console.WriteLine("No missing assemblies.");
                    }
                    Console.WriteLine();
                }
                Console.WriteLine("Done.");
                Console.WriteLine();
            }
        }
        
        private static void CheckDependencies(string filePath, string version, int depth)
        {
            try
            {
                string fileName = Path.GetFileName(filePath);
                string directory = Path.GetDirectoryName(filePath);
                directory = (String.IsNullOrEmpty(directory)) ? Environment.CurrentDirectory : Path.GetFullPath(directory);
                string fullFileName = Path.Combine(directory, fileName);

                Assembly assembly = Assembly.ReflectionOnlyLoadFrom(fullFileName);

                string actualVersion = assembly.GetName().Version.ToString();
                if (version != TOP_LEVEL && actualVersion != version)
                {
                    throw new FileNotFoundException(String.Format("Wrong version - should be v{0}, but was v{1}!", version, actualVersion), fullFileName);
                }

                // Console.WriteLine("{0}{1} v{2}", new String(' ', depth), fileName, actualVersion);
                
                foreach (AssemblyName referencedAssembly in assembly.GetReferencedAssemblies())
                {
                    if (_wellKnownAssemblies.Contains(referencedAssembly.Name))
                    {
                        continue;
                    }

                    CheckDependencies(Path.Combine(directory, referencedAssembly.Name + ".dll"), referencedAssembly.Version.ToString(), depth + 1);
                }
            }
            catch (FileNotFoundException fileNotFoundException)
            {
                // Console.WriteLine("Exception: {0}", fileNotFoundException.Message);
                string missingAssembly = String.Format("{0} v{1}", Path.GetFileName(fileNotFoundException.FileName), version);
                if (!_missingAssemblies.Contains(missingAssembly))
                {
                    _missingAssemblies.Add(missingAssembly);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine("There was an error checking the assembly dependencies:");
                Console.WriteLine(exception);
            }
        }
    }
}