using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;

namespace XmlValidation
{
    internal static class Program
    {
        private static string _schemaLocation;
        private static string _schemaFileNames;
        private static bool _skipMissingNamespace;

        private static XmlSchemaSet _schemas;

        public static void Main(string[] args)
        {
            if (!args.Any())
            {
                Console.WriteLine("There were no documents specified as arguments!");
                Environment.Exit(1);
            }
            else
            {
                Console.WriteLine("{0} document(s) specified as arguments...", args.Length);
                Console.WriteLine();
                ReadConfiguration();
                LoadSchemas();
                foreach (string arg in args)
                {
                    Validate(arg);
                }
                Console.WriteLine("Done.");
                Console.WriteLine();
                Environment.Exit(0);
            }
        }

        private static void ReadConfiguration()
        {
            Console.WriteLine("Reading the configuration...");
            try
            {
                _schemaLocation = ConfigurationManager.AppSettings["SchemaLocation"];
                _schemaFileNames = ConfigurationManager.AppSettings["SchemaFileNames"];
                _skipMissingNamespace = Convert.ToBoolean(ConfigurationManager.AppSettings["SkipMissingNamespace"]);
            }
            catch (Exception exception)
            {
                Console.WriteLine("There was an error reading the configuration:");
                Console.WriteLine(exception.Message);
                Environment.Exit(2);
            }
            Console.WriteLine();
        }

        private static void LoadSchemas()
        {
            Console.WriteLine("Loading the schema(s)...");
            try
            {
                _schemas = new XmlSchemaSet();
                foreach (string schemaFileName in _schemaFileNames.Split(';'))
                {
                    var fullFileName = Path.Combine(_schemaLocation, schemaFileName);
                    _schemas.Add(null, fullFileName);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine("There was an error loading the schema(s):");
                Console.WriteLine(exception.Message);
                Environment.Exit(3);
            }
            Console.WriteLine();
        }

        private static void Validate(string fileName)
        {
            Console.WriteLine("Considering the document '{0}'...", fileName);
            try
            {
                Console.WriteLine("Loading the document...");
                XDocument source = XDocument.Load(fileName);
                string rootElementNamespace = source.Root.Name.Namespace.ToString();
                if (!_skipMissingNamespace && string.IsNullOrWhiteSpace(rootElementNamespace))
                {
                    throw new InvalidOperationException("No namespace specified for root element!");
                }
                if (!_schemas.Contains(rootElementNamespace))
                {
                    throw new InvalidOperationException(string.Format("The {0} namespace is not supported!", rootElementNamespace));
                }
                List<string> errors = new List<string>();
                Console.WriteLine("Validating the document...");
                source.Validate(_schemas, (sender, args) => errors.Add(args.Message));
                if (errors.Any())
                {
                    Console.WriteLine("There were {0} validation error(s) for the document:", errors.Count);
                    foreach (string error in errors)
                    {
                        Console.WriteLine(" * " + error);
                    }
                }
                else
                {
                    Console.WriteLine("Document is valid.");
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine("There was an error validating the document:");
                Console.WriteLine(exception.Message);
            }
            Console.WriteLine();
        }
    }
}