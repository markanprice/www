$cancelledSchools = "GreenAbbey", "Buckingham School", "Carrfield Primary Academy", "Ecclesall Church of England School", "Mellor Primary School", "North Cheshire Jewish Primary School", "Rendell Primary School", "Tiger Primary School"
$emailSchools = Get-Content ".\Overdue School Provisioning Contact.txt" | Select-String "There has been no provisioning contact from (.+) in the last 72 hours "
$filteredSchools = $emailSchools.Matches | ForEach-Object {$_.Groups[1].Value} | Where-Object {$_ -cnotin $cancelledSchools} | Sort-Object
$count = $filteredSchools.Count
$filteredSchools
Write-Host "($count schools)"
Pause
