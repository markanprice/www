$connectionString = "Server=tcp:gd95cbywae.database.windows.net,1433;Database=Rich_Agora;User ID=Testsa@gd95cbywae;Password=Password01;Trusted_Connection=False;Encrypt=True;Connection Timeout=30;"

$command1Text = "select [Edition] = databasepropertyex('Rich_Agora', 'Edition')"
$command2Text = "select [ServiceObjective] = databasepropertyex('Rich_Agora', 'ServiceObjective')"

$connection = New-Object System.Data.SqlClient.SqlConnection($connectionString)
$connection.Open()

$command1 = New-Object System.Data.SqlClient.SqlCommand($command1Text, $connection)
$edition = $command1.ExecuteScalar()

$command2 = New-Object System.Data.SqlClient.SqlCommand($command2Text, $connection)
$serviceObjective = $command2.ExecuteScalar()

Write-Output "Edition is '$edition'"
Write-Output "ServiceObjective is '$serviceObjective'"
