$exitCode = 0

try
{
	[string]$webrootPath = $env:WEBROOT_PATH

	[string]$webConfigFileName = Join-Path $webrootPath "web.config"

	Write-Output "Configuration at '$webConfigFileName'"

	[xml]$webConfigXml = Get-Content $webConfigFileName

	[string]$connectionString = Select-Xml -Xml $webConfigXml -XPath "/configuration/appSettings/add[@key='agora.storage.connection-string']/@value"

	[string]$queueName = "emaildispatchqueue"

	$context = New-AzureStorageContext -ConnectionString $connectionString

	$queue = Get-AzureStorageQueue -Name $queueName -Context $context

	$count = $queue.ApproximateMessageCount

	Write-Output "Queue's approximate message count is $count"
}
catch
{
	Write-Error "Unexpected exception:"
	Write-Error $_
	$exitCode = -1
}

exit $exitCode
