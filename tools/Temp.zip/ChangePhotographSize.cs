using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;

namespace ChangePhotographSize
{
    public class Program
    {
        public static void Main(string[] args)
        {
            if (args.Length != 4 ||
                args.Any(arg => arg.StartsWith("/?") || arg.ToUpper().StartsWith("/H")))
            {
                DisplayUsage();
                return;
            }
            
            try
            {
                string sourceFileName = args[0];
                string targetFileName = args[1];
                int maxWidth = Convert.ToInt32(args[2]);
                int maxHeight = Convert.ToInt32(args[3]);
                
                var sourceImage = Image.FromFile(sourceFileName);
                
                var stopwatch = Stopwatch.StartNew();
                var targetImage = Resize(sourceImage, maxWidth, maxHeight, true);
                stopwatch.Stop();
                
                targetImage.Save(targetFileName, ImageFormat.Jpeg);
                Console.WriteLine("Photograph size changed successfully (took {0}ms)", stopwatch.ElapsedMilliseconds);
            }
            catch (Exception caught)
            {
                Console.WriteLine("Error: Exception changing photograph size!");
                Console.WriteLine(caught);
            }
        }

        private static void DisplayUsage()
        {
            Console.WriteLine("Change photograph size from and to files on disk");
            Console.WriteLine();
            Console.WriteLine("Usage:  ChangePhotographSize <SourceFileName> <TargetFileName> <MaxWidth> <MaxHeight>");
            Console.WriteLine();
            Console.WriteLine("Where:");
            Console.WriteLine("   SourceFileName   The file name of the source image");
            Console.WriteLine("   TargetFileName   The file name of the target image");
            Console.WriteLine("   MaxWidth         The maximum width in pixels of the target image");
            Console.WriteLine("   MaxHeight        The maximum height in pixels of the target image");
            Console.WriteLine();
            Console.WriteLine("Note:");
            Console.WriteLine("   Aspect ratio of the source image will be preserved");
        }

        public static Image Resize(Image image, int maxWidth, int maxHeight, bool preserveAspectRatio)
        {
            int newWidth;
            int newHeight;
            if (preserveAspectRatio)
            {
                int originalWidth = image.Width;
                int originalHeight = image.Height;

                float percentWidth = (float)maxWidth / (float)originalWidth;
                float percentHeight = (float)maxHeight / (float)originalHeight;
                float percent = Math.Min(percentWidth, percentHeight);

                newWidth = (int)(originalWidth * percent);
                newHeight = (int)(originalHeight * percent);
            }
            else
            {
                newWidth = maxWidth;
                newHeight = maxHeight;
            }

            Bitmap newImage = new Bitmap(newWidth, newHeight, PixelFormat.Format32bppArgb);

            using (Graphics graphics = Graphics.FromImage(newImage))
            {
                graphics.CompositingQuality = CompositingQuality.HighQuality;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                graphics.DrawImage(image, 0, 0, newWidth, newHeight);
            }

            return newImage;
        }
    }
}
