Param(
	[string]$edition,
    [string]$serviceObjective
)

[string]$webrootPath = $env:WEBROOT_PATH

[string]$webConfigFileName = Join-Path $webrootPath "web.config"

[xml]$webConfigXml = Get-Content $webConfigFileName

Write-Output "Configuration at '$webConfigFileName'"

[string]$connectionString = Select-Xml -Xml $webConfigXml -XPath "/configuration/appSettings/add[@key='setting.capita.agora.database.sql-connection-string']/@value"

$connectionStringBuilder = New-Object System.Data.SqlClient.SqlConnectionStringBuilder($connectionString)

[string]$server = $connectionStringBuilder.DataSource
[string]$database = $connectionStringBuilder.InitialCatalog

Write-Output "Server is '$server'"
Write-Output "Database is '$database'"

[string]$commandText = "alter database $database modify (edition = '$edition', service_objective = '$serviceObjective')"

$connection = New-Object System.Data.SqlClient.SqlConnection($connectionString)
try
{
	$connection.Open()

	$command = New-Object System.Data.SqlClient.SqlCommand($commandText, $connection)
	try
	{
		$result = $command.ExecuteNonQuery()
		
		Write-Output "Requested Edition to be '$edition' and ServiceObjective to be '$serviceObjective'"
	}
	finally
	{
		$command.Dispose()
	}
}
finally
{
	$connection.Dispose()
}
