Param(
	[string]$edition,
    [string]$serviceObjective
)

$connectionString = "Server=tcp:gd95cbywae.database.windows.net,1433;Database=Rich_Agora;User ID=Testsa@gd95cbywae;Password=Password01;Trusted_Connection=False;Encrypt=True;Connection Timeout=30;"

$commandText = "alter database Rich_Agora modify(edition = '$edition', service_objective = '$serviceObjective')"

$connection = New-Object System.Data.SqlClient.SqlConnection($connectionString)
$connection.Open()

$command = New-Object System.Data.SqlClient.SqlCommand($commandText, $connection)
$command.ExecuteNonQuery()
