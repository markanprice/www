using System;
using Ionic.Zip;

namespace TextZipFiles
{
    public class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                Console.WriteLine("Usage:  TestZipFiles [zipfile [zipfile [...]]]");
                return;
            }

            foreach (string arg in args)
            {
                Console.WriteLine("Considering zip file '{0}'...", arg);
                using (ZipFile file = ZipFile.Read(arg))
                {
                    Console.WriteLine(" - Comment: {0}", file.Comment ?? "(none)");
                    Console.WriteLine(" - Count: {0}", file.Count);
                    foreach (ZipEntry entry in file)
                    {
                        Console.WriteLine(" - {0}:", entry.FileName);
                        Console.WriteLine("    - Comment: {0}", entry.Comment ?? "(none)");
                        Console.WriteLine("    - Crc: {0}", entry.Crc);
                        Console.WriteLine("    - Encryption: {0}", entry.Encryption);
                    }
                }
                Console.WriteLine();
            }

            Console.WriteLine("Done.");
        }
    }
}