create procedure dbo.WebJob_SqlEditionServiceObjective
as

set nocount on

declare @DbName                     nvarchar(128)
,       @UtcNow                     datetime
,       @ExpectedEdition            nvarchar(10)
,       @ExpectedServiceObjective   nvarchar(10)
,       @DayOfWeek                  int
,       @HourOfDay                  int

set     @DbName = db_name()

set     @UtcNow = getutcdate()

set datefirst 1  -- ie 'Monday'

set     @DayOfWeek = datepart(dw, @UtcNow)
set     @HourOfDay = datepart(hh, @UtcNow)

if      @DayOfWeek between 1 and 5  -- ie 'Monday' to 'Friday'
and     @HourOfDay >= 6  -- ie '06:00'
and     @HourOfDay < 18  -- ie '18:00'
begin
        set     @ExpectedEdition = 'Premium'
        set     @ExpectedServiceObjective = 'P1'
end
else
begin
        set     @ExpectedEdition = 'Standard'
        set     @ExpectedServiceObjective = 'S2'
end

select  [ActualEdition] = isnull(databasepropertyex(@dbname, 'Edition'), 'Unknown')
,       [ActualServiceObjective] = isnull(databasepropertyex(@dbname, 'ServiceObjective'), 'Unknown')
,       [ExpectedEdition] = @ExpectedEdition
,       [ExpectedServiceObjective] = @ExpectedServiceObjective

return  0
