if not exists (
        select  1
        from    sims.db_update_log
        where   patch_id = 19987
        )
begin
        declare @error_msg varchar(100)
        set     @error_msg = char(10) + char(13) + 'This patch cannot be run as Patch 19987 has not already been run.' + char(10) + char(13)
        raiserror(@error_msg, 18, 1)
        return
end
go
