/******************************************************************************
 Withdraw patch 20365:  After applying this patch dietary preferences will be displayed properly in student onroll report.
******************************************************************************/

if not exists (select 1 from sims.db_withdrawn_patch where patch_id = 20365)
begin
    insert  sims.db_withdrawn_patch(patch_id)
    values  (20365)
end
go
